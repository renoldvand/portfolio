LOGIN & REGISTER - PHP + MySQL

CARA INSTALL:
1. Nyalakan XAMPP (Apache + MySQL)
2. Buka phpMyAdmin: http://localhost/phpmyadmin
3. Import file database.sql
4. Copy semua file ke: C:\xampp\htdocs\login-register\
5. Buka: http://localhost/login-register/register.php

DEFAULT: username=admin password=rahasia123