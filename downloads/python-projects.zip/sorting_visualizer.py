# Sorting Visualizer - Rama Juliantara
import time,random
def bubble_sort(arr):n=len(arr);steps=0
    for i in range(n-1):
        for j in range(n-1-i):steps+=1;print(f'  Bandingkan [{j}]={arr[j]} dan [{j+1}]={arr[j+1]}',end=' ')
        if arr[j]>arr[j+1]:arr[j],arr[j+1]=arr[j+1],arr[j];print('SWAP ->',arr)
        else:print('OK')
        time.sleep(0.1)
    return steps
def selection_sort(arr):n=len(arr);steps=0
    for i in range(n-1):mi=i
        for j in range(i+1,n):steps+=1
            if arr[j]<arr[mi]:mi=j
        if mi!=i:print(f'  Pindah [{mi}]={arr[mi]} ke [{i}]={arr[i]} ->',end=' ');arr[i],arr[mi]=arr[mi],arr[i];print(arr);time.sleep(0.1)
    return steps
def vis(arr):mx=max(arr) if arr else 1
    for v in arr:print(f'  {v:>3} | '+'#'*int(v/mx*30))
def main():
    print('='*45);print('  SORTING VISUALIZER - Rama Juliantara');print('='*45)
    sz=max(5,min(20,int(input('Jumlah elemen (5-20): '))))
    arr=[random.randint(5,99) for _ in range(sz)]
    print(f'\nData: {arr}');print('\nVisualisasi:');vis(arr)
    p=input('\n1. Bubble Sort\n2. Selection Sort\nPilih: ')
    arr2=arr.copy();st=bubble_sort(arr2) if p=='1' else selection_sort(arr2)
    nm='Bubble Sort' if p=='1' else 'Selection Sort'
    print(f'\n--- Hasil {nm} ---');print(f'Awal : {arr}');print(f'Akhir: {arr2}');print(f'Langkah: {st}');print('\nVisualisasi:');vis(arr2)
if __name__=='__main__':main()