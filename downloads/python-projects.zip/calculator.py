# Calculator Terminal - Rama Juliantara
def tambah(a,b):return a+b
def kurang(a,b):return a-b
def kali(a,b):return a*b
def bagi(a,b):return 'Error' if b==0 else a/b
def main():
    print('='*35);print('   CALCULATOR - Rama Juliantara');print('='*35)
    print('1. Pertambahan (+)\n2. Pengurangan (-)\n3. Perkalian (*)\n4. Pembagian (/)\n0. Keluar');print('='*35)
    while True:
        p=input('\nPilih (0-4): ')
        if p=='0':print('Terima kasih!');break
        if p not in '1234':print('Pilihan tidak valid!');continue
        try:
            a=float(input('Angka 1: '));b=float(input('Angka 2: '))
        except:print('Input harus angka!');continue
        ops={'1':('+',tambah),'2':('-',kurang),'3':('*',kali),'4':('/',bagi)}
        sym,fn=ops[p];print(f'Hasil: {a} {sym} {b} = {fn(a,b)}')
if __name__=='__main__':main()