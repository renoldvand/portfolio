PROJECT PYTHON - Rama Juliantara

CARA JALANKAN:
1. Buka terminal
2. python calculator.py
3. python kasir.py
4. python sorting_visualizer.py