# Sistem Kasir - Rama Juliantara
menu={'Nasi Goreng':15000,'Mie Ayam':12000,'Bakso':10000,'Es Teh':5000,'Es Jeruk':7000,'Kopi':6000,'Ayam Geprek':18000,'Sate':20000}
def main():
    print('='*40);print('   SISTEM KASIR - Rama Juliantara');print('='*40)
    keranjang=[]
    while True:
        print('\n'+'='*40);print('        MENU TOKO RAMA');print('='*40)
        for i,(n,h) in enumerate(menu.items(),1):print(f'  {i}. {n:<16} Rp {h:>8,}')
        print('='*40)
        p=input('\nPilih (0=selesai): ')
        if p=='0':break
        try:
            idx=int(p)-1;nama=list(menu.keys())[idx];jml=int(input(f'Jumlah {nama}: '))
            if jml>0:keranjang.append((nama,menu[nama],jml));print(f'  + {jml}x {nama} ditambahkan')
        except:print('  Input tidak valid!')
    if not keranjang:print('\nKeranjang kosong.');return
    print('\n'+'='*40);print('     STRUK PEMBAYARAN');print('='*40)
    total=0
    for n,h,j in keranjang:s=h*j;total+=s;print(f'  {n:<16} {j}x  Rp {s:>10,}')
    print('-'*40);print(f'  TOTAL                Rp {total:>10,}')
    print('='*40);print('    Terima kasih!');print('='*40)
if __name__=='__main__':main()