CRUD DATA SISWA - PHP + MySQL

CARA INSTALL:
1. Nyalakan XAMPP (Apache + MySQL)
2. Buka phpMyAdmin: http://localhost/phpmyadmin
3. Import file database.sql
4. Copy semua file ke: C:\xampp\htdocs\crud-siswa\
5. Buka: http://localhost/crud-siswa/