CREATE DATABASE IF NOT EXISTS db_crud_siswa;
USE db_crud_siswa;

CREATE TABLE IF NOT EXISTS siswa (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  kelas VARCHAR(20) NOT NULL,
  jurusan VARCHAR(50) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO siswa (nama, kelas, jurusan) VALUES
('Rama Juliantara', '11 RPL 1', 'RPL'),
('Budi Santoso', '11 RPL 1', 'RPL'),
('Sari Dewi', '11 TKJ 2', 'TKJ');